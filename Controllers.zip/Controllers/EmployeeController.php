<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (auth()->check() && auth()->user()->role === 'employee') {
                abort(403, 'Tài khoản của bạn không có quyền truy cập khu vực Quản lý!');
            }
            return $next($request);
        });
    }

    public function index()
    {
        $employees = Employee::all();
        return view('admin.employees.index', compact('employees'));
    }

    public function create()
    {
        return view('admin.employees.create');
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'full_name' => 'required|string|max:255',
            'phone_number' => 'required|string|unique:employees',
            'cccd' => 'required|string|unique:employees',
            'type' => 'required|in:full-time,part-time,probation',
            'position' => 'required|in:barista,server,cashier,manager,guard',
        ]);

        Employee::create($validatedData);

        return redirect()->route('employees.index')->with('success', 'Thêm nhân sự mới thành công!');
    }

    // ---------------- THÊM MỚI TỪ ĐÂY ----------------

    // Hiển thị form Sửa thông tin
    public function edit(Employee $employee)
    {
        return view('admin.employees.edit', compact('employee'));
    }

    // Lưu thông tin Sửa vào Database
    public function update(Request $request, Employee $employee)
    {
        $validatedData = $request->validate([
            'full_name' => 'required|string|max:255',
            // Bỏ qua check unique cho chính ID của nhân viên đang sửa
            'phone_number' => 'required|string|unique:employees,phone_number,' . $employee->id,
            'cccd' => 'required|string|unique:employees,cccd,' . $employee->id,
            'type' => 'required|in:full-time,part-time,probation',
            'position' => 'required|in:barista,server,cashier,manager,guard',
        ]);

        $employee->update($validatedData);

        return redirect()->route('employees.index')->with('success', 'Cập nhật thông tin nhân sự thành công!');
    }

    // Xử lý Xóa nhân sự (Bảo mật: Chỉ Admin)
    public function destroy(Employee $employee)
    {
        // Khóa bảo mật lớp 2 (Backend)
        if (auth()->user()->role !== 'admin') {
            abort(403, 'CẢNH BÁO: Chỉ Admin mới có quyền xóa dữ liệu!');
        }

        $employee->delete();

        return redirect()->route('employees.index')->with('success', 'Đã xóa nhân sự khỏi hệ thống!');
    }
}