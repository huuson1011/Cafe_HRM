<?php

namespace App\Http\Controllers;

use App\Models\Shift;
use Illuminate\Http\Request;

class ShiftController extends Controller
{
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            // Chỉ Admin và Manager mới được thao tác với Ca làm việc
            if (auth()->check() && auth()->user()->role === 'employee') {
                abort(403, 'Chỉ Quản lý và Admin mới có quyền thiết lập ca làm việc!');
            }
            return $next($request);
        });
    }

    public function index()
    {
        $shifts = Shift::all();
        return view('admin.shifts.index', compact('shifts'));
    }

    public function create()
    {
        return view('admin.shifts.create');
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'shift_name' => 'required|string|max:255',
            'start_time' => 'required',
            'end_time' => 'required',
        ]);

        Shift::create($validatedData);

        return redirect()->route('shifts.index')->with('success', 'Tạo ca làm việc mới thành công!');
    }

    public function destroy(Shift $shift)
    {
        // Khóa bảo vệ: Giống như nhân sự, chỉ Admin mới được XÓA ca
        if (auth()->user()->role !== 'admin') {
            abort(403, 'CẢNH BÁO: Chỉ Admin mới có quyền xóa dữ liệu!');
        }
        
        $shift->delete();
        return redirect()->route('shifts.index')->with('success', 'Đã xóa ca làm việc!');
    }
}