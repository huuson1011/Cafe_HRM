<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        // Lấy thông tin user hiện tại truyền ra View để hiển thị
        $user = Auth::user();
        return view('dashboard', compact('user'));
    }
}