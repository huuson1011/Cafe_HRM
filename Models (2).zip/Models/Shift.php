<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    use HasFactory;

    // Cho phép thêm dữ liệu hàng loạt vào các cột này
    protected $fillable = [
        'shift_name',
        'start_time',
        'end_time',
    ];
}