<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Highlands Coffee - Tự hào sinh ra từ Đất Việt</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f8f8f8; }
        header { background-color: #b22830; color: white; padding: 15px 50px; display: flex; justify-content: space-between; align-items: center; }
        .logo { font-size: 24px; font-weight: bold; text-decoration: none; color: white; }
        nav { display: flex; gap: 30px; align-items: center; }
        nav a { color: white; text-decoration: none; font-size: 16px; font-weight: 500; text-transform: uppercase; transition: 0.3s; }
        nav a:hover { color: #f1c40f; }
        .btn-login { background-color: transparent; border: 2px solid white; padding: 8px 20px; border-radius: 20px; }
        .btn-login:hover { background-color: white; color: #b22830; }
        .hero { background-image: url('https://images.unsplash.com/photo-1497935586351-b67a49e012bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80'); background-size: cover; background-position: center; height: 500px; display: flex; align-items: center; justify-content: center; color: white; text-align: center; }
        .hero-content { background: rgba(0, 0, 0, 0.6); padding: 40px; border-radius: 10px; }
        .hero h1 { font-size: 48px; margin: 0 0 15px 0; }
        .hero p { font-size: 20px; margin: 0; }
    </style>
</head>
<body>

<header>
    <a href="/" class="logo">HIGHLANDS COFFEE</a>
    <nav>
        <a href="#gioi-thieu">Giới thiệu</a>
        <a href="#tin-tuc">Tin tức</a>
        <a href="#ung-tuyen">Tuyển dụng</a>
        
        @auth
            <a href="/dashboard" style="color: #f1c40f; font-weight: bold;">VÀO DASHBOARD</a>

            <form action="{{ route('logout') }}" method="POST" style="display:inline;">
                @csrf
                <button type="submit" style="background:none; border:none; color:white; cursor:pointer; font-weight:bold; font-size:16px;">ĐĂNG XUẤT</button>
            </form>
        @else
            <a href="/login" class="btn-login">Đăng nhập Cửa hàng</a>
        @endauth
    </nav>
</header>

<div class="hero">
    <div class="hero-content">
        <h1>Cà Phê Đích Thực</h1>
        <p>Đậm đà hương vị truyền thống Việt Nam</p>
    </div>
</div>

<div style="padding: 50px; text-align: center; color: #333;" id="gioi-thieu">
    <h2>Hành trình của chúng tôi</h2>
    <p>Bắt đầu từ một tình yêu dành cho đất Việt cùng với cà phê và cộng đồng nơi đây, chúng tôi đã không ngừng mang đến những ly cà phê thơm ngon, sánh đượm trong không gian thoải mái và lịch sự.</p>
</div>

</body>
</html>