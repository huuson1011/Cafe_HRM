<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tạo Ca làm việc</title>
</head>
<body style="font-family: Arial; padding: 20px;">
    <h2>Tạo Ca làm việc mới</h2>
    <a href="{{ route('shifts.index') }}" style="color: #666; text-decoration: none;">← Quay lại</a><br><br>

    <form action="{{ route('shifts.store') }}" method="POST" style="max-width: 400px; padding: 20px; border: 1px solid #ddd; background: #f9f9f9;">
        @csrf
        <div style="margin-bottom: 15px;">
            <label>Tên Ca (VD: Ca Sáng, Ca Chiều):</label><br>
            <input type="text" name="shift_name" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>
        <div style="margin-bottom: 15px;">
            <label>Giờ bắt đầu:</label><br>
            <input type="time" name="start_time" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>
        <div style="margin-bottom: 20px;">
            <label>Giờ kết thúc:</label><br>
            <input type="time" name="end_time" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>
        <button type="submit" style="width: 100%; padding: 10px; background: #3498db; color: white; border: none; font-weight: bold; cursor: pointer;">Lưu Ca làm việc</button>
    </form>
</body>
</html>