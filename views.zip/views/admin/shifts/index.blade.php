<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Ca làm việc</title>
</head>
<body style="font-family: Arial; padding: 20px;">
    <h2>Danh sách Ca làm việc Cố định</h2>
    
    <a href="/dashboard" style="color: #666; text-decoration: none;">← Về Dashboard</a><br><br>

    <a href="{{ route('shifts.create') }}" style="padding: 8px 15px; background: #2ecc71; color: white; text-decoration: none;">+ Tạo ca mới</a>
    <br><br>
    
    @if(session('success'))
        <div style="color: green; padding: 10px; background: #e8f8f5; border: 1px solid #2ecc71; margin-bottom: 15px;">
            {{ session('success') }}
        </div>
    @endif

    <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: center; border-collapse: collapse;">
        <thead style="background-color: #f2f2f2;">
            <tr>
                <th>ID</th>
                <th>Tên Ca</th>
                <th>Giờ bắt đầu</th>
                <th>Giờ kết thúc</th>
                @if(Auth::user()->role === 'admin')
                    <th>Hành động</th>
                @endif
            </tr>
        </thead>
        <tbody>
            @foreach($shifts as $shift)
            <tr>
                <td>{{ $shift->id }}</td>
                <td><strong>{{ $shift->shift_name }}</strong></td>
                <td>{{ $shift->start_time }}</td>
                <td>{{ $shift->end_time }}</td>
                
                @if(Auth::user()->role === 'admin')
                <td>
                    <form action="{{ route('shifts.destroy', $shift->id) }}" method="POST" onsubmit="return confirm('Xóa ca này?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" style="background: red; color: white; border: none; padding: 6px 10px; cursor: pointer;">Xóa</button>
                    </form>
                </td>
                @endif
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>