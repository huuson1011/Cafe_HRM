<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm Nhân sự</title>
</head>
<body style="font-family: Arial; padding: 20px;">
    <h2>Thêm Nhân sự Mới</h2>
    <a href="{{ route('employees.index') }}">← Quay lại</a><br><br>

    <form action="{{ route('employees.store') }}" method="POST">
        @csrf
        <div style="margin-bottom: 10px;">
            <label>Họ và Tên:</label><br>
            <input type="text" name="full_name" required>
        </div>
        <div style="margin-bottom: 10px;">
            <label>Số điện thoại:</label><br>
            <input type="text" name="phone_number" required>
        </div>
        <div style="margin-bottom: 10px;">
            <label>CCCD:</label><br>
            <input type="text" name="cccd" required>
        </div>
        <div style="margin-bottom: 10px;">
            <label>Loại hợp đồng:</label><br>
            <select name="type" required>
                <option value="part-time">Part-time</option>
                <option value="full-time">Full-time</option>
                <option value="probation">Thử việc</option>
            </select>
        </div>
        <div style="margin-bottom: 20px;">
            <label>Vị trí:</label><br>
            <select name="position" required>
                <option value="barista">Pha chế (Barista)</option>
                <option value="server">Phục vụ</option>
                <option value="cashier">Thu ngân</option>
                <option value="manager">Quản lý</option>
                <option value="guard">Bảo vệ</option>
            </select>
        </div>
        <button type="submit" style="padding: 10px 20px; background: #3498db; color: white; border: none;">Lưu thông tin</button>
    </form>
</body>
</html>