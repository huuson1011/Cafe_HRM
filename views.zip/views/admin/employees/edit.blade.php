<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa Nhân sự</title>
</head>
<body style="font-family: Arial; padding: 20px;">
    <h2>Cập nhật thông tin: {{ $employee->full_name }}</h2>
    <a href="{{ route('employees.index') }}" style="color: #666; text-decoration: none;">← Quay lại danh sách</a><br><br>

    @if ($errors->any())
        <div style="color: red; margin-bottom: 15px;">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('employees.update', $employee->id) }}" method="POST" style="max-width: 400px; padding: 20px; border: 1px solid #ddd; background: #f9f9f9;">
        @csrf
        @method('PUT') <div style="margin-bottom: 15px;">
            <label>Họ và Tên:</label><br>
            <input type="text" name="full_name" value="{{ old('full_name', $employee->full_name) }}" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>
        <div style="margin-bottom: 15px;">
            <label>Số điện thoại:</label><br>
            <input type="text" name="phone_number" value="{{ old('phone_number', $employee->phone_number) }}" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>
        <div style="margin-bottom: 15px;">
            <label>CCCD:</label><br>
            <input type="text" name="cccd" value="{{ old('cccd', $employee->cccd) }}" required style="width: 100%; padding: 8px; box-sizing: border-box;">
        </div>
        <div style="margin-bottom: 15px;">
            <label>Loại hợp đồng:</label><br>
            <select name="type" required style="width: 100%; padding: 8px;">
                <option value="part-time" {{ $employee->type == 'part-time' ? 'selected' : '' }}>Part-time</option>
                <option value="full-time" {{ $employee->type == 'full-time' ? 'selected' : '' }}>Full-time</option>
                <option value="probation" {{ $employee->type == 'probation' ? 'selected' : '' }}>Thử việc</option>
            </select>
        </div>
        <div style="margin-bottom: 20px;">
            <label>Vị trí:</label><br>
            <select name="position" required style="width: 100%; padding: 8px;">
                <option value="barista" {{ $employee->position == 'barista' ? 'selected' : '' }}>Pha chế (Barista)</option>
                <option value="server" {{ $employee->position == 'server' ? 'selected' : '' }}>Phục vụ</option>
                <option value="cashier" {{ $employee->position == 'cashier' ? 'selected' : '' }}>Thu ngân</option>
                <option value="manager" {{ $employee->position == 'manager' ? 'selected' : '' }}>Quản lý</option>
                <option value="guard" {{ $employee->position == 'guard' ? 'selected' : '' }}>Bảo vệ</option>
            </select>
        </div>
        <button type="submit" style="width: 100%; padding: 10px; background: #3498db; color: white; border: none; font-weight: bold; cursor: pointer;">Cập nhật thông tin</button>
    </form>
</body>
</html>