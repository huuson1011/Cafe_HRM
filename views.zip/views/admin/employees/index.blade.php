<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách nhân viên</title>
</head>
<body style="font-family: Arial; padding: 20px;">
    <h2>Danh sách Nhân sự Quán</h2>
    
    <p>Xin chào, <strong>{{ Auth::user()->name }}</strong> (Quyền: {{ strtoupper(Auth::user()->role) }})</p>
    
    <a href="/" style="color: #666; text-decoration: none;">← Về trang chủ</a><br><br>

    @if(Auth::user()->role === 'admin' || Auth::user()->role === 'manager')
        <a href="{{ route('employees.create') }}" style="padding: 8px 15px; background: #2ecc71; color: white; text-decoration: none;">+ Thêm nhân sự</a>
    @endif
    <br><br>
    
    @if(session('success'))
        <div style="color: green; padding: 10px; background: #e8f8f5; border: 1px solid #2ecc71; margin-bottom: 15px;">
            {{ session('success') }}
        </div>
    @endif

    <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: left; border-collapse: collapse;">
        <thead style="background-color: #f2f2f2;">
            <tr>
                <th>ID</th>
                <th>Họ Tên</th>
                <th>Vị trí</th>
                <th>Loại hình</th>
                <th>SĐT</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            @foreach($employees as $emp)
            <tr>
                <td>{{ $emp->id }}</td>
                <td>{{ $emp->full_name }}</td>
                <td>{{ ucfirst($emp->position) }}</td>
                <td>{{ ucfirst($emp->type) }}</td>
                <td>{{ $emp->phone_number }}</td>
                <td>
                    <a href="{{ route('employees.edit', $emp->id) }}" style="padding: 5px 10px; background: #f1c40f; color: black; text-decoration: none; border-radius: 3px; font-size: 14px;">Sửa</a>
                    
                    @if(Auth::user()->role === 'admin')
                        <form action="{{ route('employees.destroy', $emp->id) }}" method="POST" style="display:inline;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa nhân sự này không?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" style="background: red; color: white; border: none; padding: 6px 10px; cursor: pointer; border-radius: 3px; font-size: 14px; margin-left: 5px;">Xóa</button>
                        </form>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>