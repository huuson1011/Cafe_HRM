<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Cafe HRM</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; display: flex; height: 100vh; background-color: #f4f7f6; }
        .sidebar { width: 250px; background-color: #2c3e50; color: white; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { margin-top: 0; font-size: 20px; color: #ecf0f1; border-bottom: 1px solid #34495e; padding-bottom: 10px; }
        .sidebar p { font-size: 14px; color: #bdc3c7; margin-bottom: 30px; }
        .menu-item { display: block; padding: 12px 15px; margin-bottom: 8px; background-color: #34495e; color: white; text-decoration: none; border-radius: 4px; transition: 0.3s; }
        .menu-item:hover { background-color: #3498db; }
        .content { flex: 1; padding: 30px; overflow-y: auto; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
        .logout-btn { background-color: #e74c3c; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; }
        .logout-btn:hover { background-color: #c0392b; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Cafe HRM</h2>
        <p>Xin chào, <strong>{{ $user->name }}</strong><br>Role: {{ strtoupper($user->role) }}</p>

        <a href="/dashboard" class="menu-item">Trang Tổng quan</a>
        
        @if($user->role === 'admin')
            <div style="margin-top: 20px; color: #7f8c8d; font-size: 12px; font-weight: bold; text-transform: uppercase;">Quản trị hệ thống</div>
            <a href="{{ route('employees.index') }}" class="menu-item">Quản lý Nhân sự</a>
            <a href="{{ route('shifts.index') }}" class="menu-item">Thiết lập Ca làm việc</a>
            <a href="#" class="menu-item">Báo cáo Tổng</a>
        @endif

        @if($user->role === 'manager')
            <div style="margin-top: 20px; color: #7f8c8d; font-size: 12px; font-weight: bold; text-transform: uppercase;">Quản lý Cửa hàng</div>
            <a href="{{ route('employees.index') }}" class="menu-item">Hồ sơ Nhân viên</a>
            <a href="{{ route('shifts.index') }}" class="menu-item">Thiết lập Ca làm việc</a>
            <a href="#" class="menu-item">Duyệt Chấm công</a>
        @endif

        @if($user->role === 'employee')
            <div style="margin-top: 20px; color: #7f8c8d; font-size: 12px; font-weight: bold; text-transform: uppercase;">Cá nhân</div>
            <a href="#" class="menu-item">Xem Lịch làm việc</a>
            <a href="#" class="menu-item">Đăng ký / Đổi ca</a>
            <a href="#" class="menu-item">Phiếu lương</a>
        @endif
        
        <br>
        <a href="/" style="color: #95a5a6; text-decoration: none; font-size: 14px;">← Quay ra Trang chủ</a>
    </div>

    <div class="content">
        <div class="header">
            <h1 style="margin: 0; color: #2c3e50;">Tổng quan</h1>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="logout-btn">Đăng xuất</button>
            </form>
        </div>

        <div class="card">
            <h3>Chào mừng đến với hệ thống nội bộ</h3>
            <p>Hãy chọn chức năng tương ứng trên thanh công cụ bên trái.</p>
        </div>
    </div>

</body>
</html>