<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng nhập Hệ thống - Highlands</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background-color: #f4f7f6; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
        }
        .login-box { 
            background: white; 
            padding: 40px; 
            border-radius: 8px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.1); 
            width: 100%; 
            max-width: 350px; 
            text-align: center; 
        }
        .login-box h2 { 
            color: #b22830; 
            margin-bottom: 30px; 
        }
        input { 
            width: 100%; 
            padding: 12px; 
            margin-bottom: 20px; 
            border: 1px solid #ddd; 
            border-radius: 5px; 
            outline: none; 
            box-sizing: border-box; /* Đảm bảo input không bị tràn viền */
        }
        input:focus {
            border-color: #b22830;
        }
        button { 
            width: 100%; 
            padding: 12px; 
            background-color: #b22830; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            font-size: 16px; 
            font-weight: bold; 
            transition: background 0.3s;
        }
        button:hover { 
            background-color: #8e1f26; 
        }
        .error { 
            color: red; 
            margin-bottom: 15px; 
            font-size: 14px; 
        }
        .back-link {
            display: inline-block;
            margin-top: 15px;
            color: #666; 
            text-decoration: none; 
            font-size: 14px;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>HRM ĐĂNG NHẬP</h2>
    
    @if($errors->any())
        <div class="error">{{ $errors->first() }}</div>
    @endif

    <form action="/login" method="POST">
        @csrf
        <input type="text" name="username" placeholder="Tài khoản đăng nhập" required value="{{ old('username') }}">
        
        <input type="password" name="password" placeholder="Mật khẩu" required>
        
        <button type="submit">Đăng nhập</button>
    </form>
    
    <a href="/" class="back-link">← Quay về trang chủ</a>
</div>

</body>
</html>